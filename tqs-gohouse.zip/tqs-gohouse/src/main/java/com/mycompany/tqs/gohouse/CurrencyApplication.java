package com.mycompany.tqs.gohouse;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("REST")
public class CurrencyApplication extends Application {

}